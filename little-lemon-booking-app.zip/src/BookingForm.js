import React, { useState } from "react";

function BookingForm() {
  const [formData, setFormData] = useState({
    name: "",
    date: "",
    time: "",
    guests: 1,
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.date || !formData.time) {
      alert("Please fill in all fields.");
      return;
    }
    setSubmitted(true);
  };

  return (
    <div>
      <form onSubmit={handleSubmit} aria-label="Booking form">
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          name="name"
          aria-required="true"
          onChange={handleChange}
        />
        <br />

        <label htmlFor="date">Date:</label>
        <input
          type="date"
          name="date"
          aria-required="true"
          onChange={handleChange}
        />
        <br />

        <label htmlFor="time">Time:</label>
        <input
          type="time"
          name="time"
          aria-required="true"
          onChange={handleChange}
        />
        <br />

        <label htmlFor="guests">Guests:</label>
        <input
          type="number"
          name="guests"
          min="1"
          max="10"
          value={formData.guests}
          onChange={handleChange}
        />
        <br />

        <button type="submit">Book Table</button>
      </form>
      {submitted && <p>Booking submitted! 🎉</p>}
    </div>
  );
}

export default BookingForm;
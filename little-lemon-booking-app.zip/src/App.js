import React from "react";
import BookingForm from "./BookingForm";

function App() {
  return (
    <div>
      <h1>Little Lemon Restaurant - Table Booking</h1>
      <BookingForm />
    </div>
  );
}

export default App;